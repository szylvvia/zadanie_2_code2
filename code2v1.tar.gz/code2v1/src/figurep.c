#include "../include/libp.h"

int prostokat_p(int a, int b)
{
    float x;
    x=a*b;
    return x;
}

int prostopadloscian_p(int a, int b, int h)
{
    float x;
    x=2*(a*h)+2*(b*h)+2*(a*b);
    return x;
}

