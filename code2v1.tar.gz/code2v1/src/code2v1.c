#include <stdio.h>
#include "../include/libo.h"
#include "../include/libp.h"


int main()
{
    int x,y,z,status,temp;
    printf("***********************************************************\n");
    printf("CODE 2\n");
    printf("OBLICZANIE POLA PROSTOKATA\n");
    printf("OBLCIZANIE POLA POWIERZCHNI I OBJETOSI PROSTOPADLOSCIANU\n");
    printf("***********************************************************\n\n");

    printf("WPROWADZENIE DANYCH\n");
    printf("-------------------\n");

    printf("\n->Prostokat\n");

    printf("\nPodaj dlugosc boku prostokata: a=");
    status = scanf("%d",&x);
	while(status!=1){
		while((temp=getchar()) != EOF && temp != '\n');
		printf("Nieprawidlowe dane podaj ponownie: a= ");
		status = scanf("%d", &x);
	}

    printf("Podaj dlugosc drugiego boku prostokata: b=");
    status=scanf("%d",&y);
    while(status!=1)
    {
		while((temp=getchar()) != EOF && temp != '\n');
		printf("Nieprawidlowe dane podaj ponownie: b= ");
		status = scanf("%d", &y);
	}

    int a=prostokat_p(x,y);

	printf("\n->Prostopadloscian\n");

    printf("\nPodaj dlugosc krawedzi prostopadloscianu: a=");
    status = scanf("%d",&x);
	while(status!=1)
    {
		while((temp=getchar()) != EOF && temp != '\n');
		printf("Nieprawidlowe dane podaj ponownie: a= ");
		status = scanf("%d", &x);
	}

    printf("Podaj dlugosc drugiej krawedzi prostopadloscianu: b=");
    status = scanf("%d",&y);
	while(status!=1)
    {
		while((temp=getchar()) != EOF && temp != '\n');
		printf("Nieprawidlowe dane podaj ponownie: a= ");
		status = scanf("%d", &y);
	}

    printf("Podaj dlugosc wysokosci prostopadloscianu: h=");
    status = scanf("%d",&z);
	while(status!=1)
    {
		while((temp=getchar()) != EOF && temp != '\n');
		printf("Nieprawidlowe dane podaj ponownie: a= ");
		status = scanf("%d", &z);
	}


    int c=prostopadloscian_p(x,y,z);
    int d=prostopadloscian_o(x,y,z);


    printf("\nWyniki:\n");
    printf("--------\n");

    printf("\n->Pole prostokata: %d\n",a);

    printf("\n->Pole prostopadloscianu: %d\n",c);
    printf("\n->Objetosc prostopadloscianu: %d\n",d);

    return 0;
}
