#include "../include/libo.h"

int prostopadloscian_o(int a, int b, int h)
{
    float x;
    x=a*b*h;
    return x;
}
