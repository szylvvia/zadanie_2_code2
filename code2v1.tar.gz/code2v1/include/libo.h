#ifndef FIGUREO_H_INCLUDED
#define FIGUREO_H_INCLUDED

int prostopadloscian_o(int a, int b, int h);

#endif // FIGUREO_H_INCLUDED
