#ifndef FIGUREP_H_INCLUDED
#define FIGUREP_H_INCLUDED

int prostokat_p(int a, int b);
int prostopadloscian_p(int a, int b, int h);

#endif // FIGUREP_H_INCLUDED
